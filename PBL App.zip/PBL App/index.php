<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration and Login</title>
</head>
<body>
    <h1>Welcome to User Registration and Login System</h1>
    <h2>Choose an action:</h2>
    <ul>
        <li><a href="registerportal.html">Register</a></li>
        <li><a href="loginportal.html">Login</a></li>
    </ul>
</body>
</html>
