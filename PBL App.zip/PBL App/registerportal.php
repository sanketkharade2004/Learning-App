<?php
// Include database connection
include_once "config.php";

// Retrieve form data
$username = $_POST["username"];
$email = $_POST["email"];
$phone = $_POST["phone"];
$password = $_POST["password"];

// Insert user into database
$mysqli = "INSERT INTO users (username, email, phone, password) VALUES ('$username', '$email', '$phone', '$password');";
if ($conn->query($mysqli) === TRUE) {
    echo "Registration successful!";
} else {
    echo "Error: " . $mysqli . "<br>" . $conn->error;
}

// Close database connection
$conn->close();
?>