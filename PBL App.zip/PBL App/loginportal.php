<?php
// Include database connection
include_once "config.php";

// Retrieve form data
$username = $_POST["username"];
$password = $_POST["password"];

// Check if username and password match in the database
$sqli = "SELECT * FROM users WHERE username='$username' AND password='$password' ";
$result = $conn->query($sqli);

if ($result->num_rows == 1) {
    include_once "firstpage.html";
} else {
    echo "Login failed. Please check your username and password.";
}

// Close database connection
$conn->close();
?>
