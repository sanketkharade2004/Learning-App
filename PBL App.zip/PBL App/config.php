<?php
$dbuser="root";
$dbpass="Abhi@2993";
$host="localhost";
$db="register";
$conn=new mysqli($host,$dbuser,$dbpass,$db);

?>